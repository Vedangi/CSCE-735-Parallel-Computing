The code files are also present in /scratch/user/vedangibengali/HW2    on Ada cluster.
