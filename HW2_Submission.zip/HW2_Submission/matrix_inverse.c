#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

int main(int argc, char** argv){

    int i,j,n = 0;
    double** input_matrix;
    double** output_matrix;
    double** temp_matrix;

    double** createMatrix(int , int);
    void randomInitialize(double** , int , int);
    void upTriangularize(double** ,int );
    void recordFile(FILE *fp, double** , int , int );
    double** multiplication(double** , double** ,int);
    double** matrixInverse(double**, int);
    void compute_inverse2(double** , int , int , int , int );
    double norm(double** , double** , int );
    
    



    n = atoi(argv[1]);
    int number_threads = atoi(argv[2]);

    omp_set_num_threads(number_threads);
    input_matrix = createMatrix(n,n);

    
    randomInitialize(input_matrix,n,n);
    upTriangularize(input_matrix,n); //in place triangularize

    temp_matrix = createMatrix(n,n);
    output_matrix = createMatrix(n,n);

     for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            temp_matrix[i][j] = input_matrix[i][j];
        }
       
    }
    
    double par_start = omp_get_wtime();
    compute_inverse2(temp_matrix, 0, n-1, 0, n-1);
    double par_end = omp_get_wtime();

    printf("Time taken by Parallel compute_inverse = %10.5e\n", (par_end - par_start) );
    
    // if(number_threads >= 10)
    // {
    // printf("\n Norm is : %5.5lf \n ", norm(input_matrix,temp_matrix,n));
    // }

    
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            output_matrix[i][j] = temp_matrix[i][j];
        }
       
    }

    free(input_matrix);
    free(temp_matrix);
    free(output_matrix);

    return 0;
}

double** createMatrix(int r, int c){
    double **null_matrix = NULL;
    null_matrix = (double**)malloc(r * sizeof(double*));
    for(int i=0; i<r; i++){
        null_matrix[i] = (double*)malloc(c * sizeof(double));
    }
    
    return(null_matrix);
}


void randomInitialize(double** rmatrix, int r, int c)
{
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            rmatrix[i][j] = (((double)rand())/(double) RAND_MAX) + 0.0001;    //
            // rmatrix[i][j] = rand()%2000 + 1; 
        }
    }
    for(int j=0; j<c; j++){
        int colsum = 0;
        for(int i=0; i<r; i++){
            colsum = colsum + rmatrix[i][j];
        }
        rmatrix[j][j] = rmatrix[j][j] + colsum;
    }
}


void upTriangularize(double** tmatrix,int n){

    for(int i=0; i<n; i++){
        for(int j=0; j<i; j++){
            tmatrix[i][j] = 0;
        }
    }
}


void recordFile(FILE *fp, double** p, int r, int c)
{
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            fprintf(fp, "%5.4lf ", p[i][j]);
        }
         fprintf(fp, "\n");
    }  
    fprintf(fp, "\n ----------------------------------------------------------------------- \n ");
    fprintf(fp, " \n ----------------------------------------------------------------------- \n ");
}

// MATRIX MULTIPLICATION

double** multiplication(double** matrix1, double** matrix2, int n)
{


    double** temp = createMatrix(n, n);
    #pragma omp for collapse(2)   

        for(int i=0; i<n; i++){
            for(int j=0; j<n; j++){
                for(int k=0; k<n; k++){
                    temp[i][j] += matrix1[i][k]*matrix2[k][j];
                }
            }
        }
    return(temp);
}

//Function to sequentially calculate inverse the matrix using Gaussian Elimination and Back-substitution.

double** matrixInverse(double** matrix, int n){

    double** temp1 = createMatrix(n,n);
    int i,j,k;
    double partsum;
 

    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            
            temp1[i][j] = 0.0;
        }
    }

    for(int k=0;k<n;k++){
        temp1[k][k] = (1.0/matrix[k][k]);
    }


    for (i = n - 1; i >=0; i-- ) {
      for (j = n - 1; j > i; j--) {
         partsum = 0.0;
         for (k = i + 1; k <= j; k++ ) {
            partsum += (matrix[i][k] * temp1[k][j]);
         }
         temp1[i][j]= (-1 * temp1[i][i] * partsum);
      }
   }


   return(temp1);


}



/****************************************************************************************************/
//ComputeInverse Function
/****************************************************************************************************/

void compute_inverse2(double** matrix, int r1, int r2, int c1, int c2)
{
    int rows = r2 - r1 + 1;
    int cols = c2 - c1 + 1;
    int n = rows;
    double** mat; 
    double** inv; 
    int i,j,k,a,b;

    if(rows != cols){
        printf("Cannot calculate inverse of matrix of order %d by %d\n", rows, cols);
        exit(-1);
    }

    if(n==1) {
        matrix[r1][c1] = 1/matrix[r1][c1];
        return ;
    }

    if(n<16){
            
        mat = createMatrix(n,n);
        inv = createMatrix(n,n);

        for(a=0,i=r1;a<n,i<=r2;a++,i++){
            for(b=0,j=c1;b<n,j<=c2;b++,j++){
                mat[a][b] = matrix[i][j];
            }
        } 


        inv = matrixInverse(mat,n);
        

        for(a=0,i=r1;a<n,i<=r2;a++,i++)
        {
            for(b=0,j=c1;b<n,j<=c2;b++,j++){
                matrix[i][j] = inv[a][b];
            }
        } 

        free(mat);
        free(inv);

        return;
    }

    else
    {

    int n1=(n-1)/2;
    

	#pragma omp parallel 
    {
        #pragma omp single
        {
            #pragma omp task default(none) shared(matrix,r1,c1,n1)   //matrix,r1,c1,n1
            {
              compute_inverse2(matrix,r1,r1+n1,c1,c1+n1);
              
            }
            
            #pragma omp task default(none) shared(matrix,r1,r2,c1,c2,n1)   //r1,r2,c1,c2,n1
            {
                
                compute_inverse2(matrix,r1+n1+1,r2,c1+n1+1,c2);
               
            }
            
            #pragma omp taskwait
            

        }
    }

    #pragma omp parallel default(none) shared(matrix,r1,c1,c2,n1,n)
    {
       
        double *subR1 = (double*)malloc((n1+1)*sizeof(double));
        #pragma omp for
        for(int j=c1+n1+1; j<c2+1; ++j){
            for(int i=r1; i<r1+n1+1; ++i){
                subR1[i-r1] = 0;
                for(int k=0; k<n1+1; ++k){
                    subR1[i-r1] += -1 * matrix[i][c1+k] * matrix[r1+k][j];
            }
        }
        for(int l=0;l<n1+1;++l){
            matrix[r1+l][j]=subR1[l];
        }
    }

    double *subR2 = (double*)malloc((n-n1-1)*sizeof(double));

    #pragma omp for
        for(int i=r1;i<r1+n1+1;++i){
            for(int j=c1+n1+1;j<c1+n;++j){
                subR2[j-c1-n1-1] = 0;
                for(int k=0;k<n-n1-1;++k){
                    subR2[j-c1-n1-1] += matrix[i][c1+n1+1+k] * matrix[r1+n1+1+k][j];
                }
            }
            for(int l=0;l<n-n1-1;++l){
                matrix[i][c1+n1+1+l] = subR2[l];
            }

        }
    }

    } //else close

}

/****************************************************************************************************/
/****************************************************************************************************/
//Norm Calculation

double norm(double** matrix1, double** matrix2, int n){
    double norm_val = 0;
    double** mul_matrix = multiplication(matrix1, matrix2, n);
  
    for(int i=0; i<n; i++){
	    for(int j=0; j<n; j++){
	        if(i==j){
                mul_matrix[i][j] = mul_matrix[i][j] - 1;
		   
	        }
	    }
    }

    for(int i=0; i<n; i++){
	    for(int j=0; j<n; j++){
    	    norm_val = norm_val + (mul_matrix[i][j] * mul_matrix[i][j]);
	    }
    }
    norm_val = sqrt(norm_val);
    return(norm_val);
}




