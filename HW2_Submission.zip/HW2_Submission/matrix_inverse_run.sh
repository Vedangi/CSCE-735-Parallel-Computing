#!/bin/bash

module load intel/2017A

ulimit -S -s 1048576

icc -qopenmp -o test.exe matrix_inverse.c

echo "Running ........."
bsub < matrix_inverse_openmp.job
