#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>


// #define D_random ((double)rand()/(10.0 * (double)RAND_MAX)) - 0.05
#define D_random ((double)rand()/((double)RAND_MAX))
#define PI 3.14159265358979323846

struct XY{
    double x;
    double y;
}XY;


void initialize_grid(struct XY *grid_XY, int m){
    double h = 1.0 / (double)(m + 1);
    int idx = 0;

    for(int i = 0; i < m; i++) {
        for(int j = 0; j < m; j++) {
            grid_XY[idx].x = (i + 1) * h;
            grid_XY[idx].y = (j + 1) * h;
            idx++;
        }
    }
}


void initialize_grid2(struct XY *grid_XY, int m){
    double h = 1.0 / (double)((2*m) + 1);
    int idx = 0;

    for(int i = 0; i < m; i++) {
        for(int j = 0; j < m; j++) {
            grid_XY[idx].x = ((2*i) + 1) * h;
            grid_XY[idx].y = ((2*j) + 1) * h;
            idx++;
        }
    }
}
void initialize_lparams(double *mse_mat, int m,double min_l,double max_l,double l_step,int l_len){
 
    
    min_l = (min_l/m);
    max_l = (max_l/m);
    l_step = (l_step/m);
    double l=0.0;
    int i=0;


    for(l = min_l; l<=max_l; l+=l_step) {
       
            mse_mat[i] = l;   
            i++; 
    }
}

void initialize_f(double* grid_f, struct XY *grid_XY, int m){

    int n=m*m;
    int id;
    double d_x,d_y,ker,ker2;
    // #pragma omp parallel for shared(grid_f,n)  //codeP
    #pragma omp parallel for shared(grid_f) private(id)
    for(id = 0; id < n; id++) {
        // grid_f[id] = 1 - (((grid_XY[id].x - 0.5) * (grid_XY[id].x - 0.5)) + ((grid_XY[id].y - 0.5) * (grid_XY[id].y - 0.5))) + D_random;
        grid_f[id]=0.02*(D_random-0.5); //D_random
        
        d_x = ((grid_XY[id].x - 0.25) * (grid_XY[id].x - 0.25) * m * m )/4;
        d_y = ((grid_XY[id].y - 0.25) * (grid_XY[id].y - 0.25) * m * m )/4;
        double ker = (sqrt(1/(2*PI))) * (exp(-0.5 * (d_x + d_y)));
        double ker2 = (0.2*grid_XY[id].x)+(0.1*grid_XY[id].y);

        grid_f[id]=grid_f[id]+ ker + ker2;
        


    }
}

void initialize_f2(double* grid_f, struct XY *grid_XY, int m){

    int n=m*m;
    int id;
    
    #pragma omp parallel for shared(grid_f) private(id)
    for(id = 0; id < n; id++) {
    
    double val = (double)PI / (double)m;
    grid_f[id] = sin(val*grid_XY[id].x) + cos(val*grid_XY[id].y) + (0.2*D_random);
    

    }
}

void print_grid(struct XY *grid_XY, int m){
    printf("\n Printing Grid \n");
    int idx = 0;
    for(int i=0; i<m; i++){
        for(int j=0; j<m; j++){
            printf("(%5.5lf %5.5lf) ", grid_XY[idx].x, grid_XY[idx].y);
            idx++;
        }
        printf("\n");
    }
}


void printF(double *f, int m){
  
    int idx = 0;
    for(int i=0; i<m; i++){
        for(int j=0; j<m; j++){
            printf("(%5.5lf) ", f[idx]);
            idx++;
        }
        printf("\n");
    }
}


void print_F(double *f, int n){

    for(int i=0; i<n; i++){
            printf("(%5.5lf) ", f[i]);
    }
}

void print_matrix(double** matrix,int n){
  
    for(int i = 0;i < n;i++){
        for(int j = 0; j < n ;j++){
            printf("%f ",matrix[i][j]);
        }
        printf("\n");
    }
}

double** createMatrix(int r, int c){
    double **null_matrix = NULL;
    null_matrix = (double**)malloc(r * sizeof(double*));
    for(int i=0; i<r; i++){
        null_matrix[i] = (double*)malloc(c * sizeof(double));
    }
    
    return(null_matrix);
}


void initialize_Kmatrix(double** K0, int n, struct XY *grid_XY,double l1,double l2)
{   

    double dist,dist_x,dist_y;
    int i,j;
    
    #pragma omp parallel for shared(K0) private(i)
    for(i=0;i<n;i++){
        
        #pragma omp parallel for shared(K0,i) private(j)
        for(j=0;j<n;j++){

            dist_x = pow(grid_XY[i].x - grid_XY[j].x, 2);
            dist_x= dist_x/(l1 * l1);
            
            dist_y = pow(grid_XY[i].y - grid_XY[j].y, 2);
            
            dist_y = dist_y/(l2 * l2);
            dist=dist_x+dist_y;
        
            K0[i][j] = sqrt(1/(2*PI)) * exp(-0.5 * dist);
        
        }
    }
    
}

void initialize_Atrain(double** K,double** A,int ntrain,int* itrain ){
    
    int i,j;
    #pragma omp parallel for shared(A) private(i)        //codeP
    for(i=0;i<ntrain;i++){
        #pragma omp parallel for shared(A,i) private(j)    //codeP
         for(j=0;j<ntrain;j++){

             A[i][j]=K[itrain[i]][itrain[j]];

             if(i==j)
                A[i][j] = A[i][j] + 0.5; //t param = 0.5
        
    }
    }
}

void init_smallk(double** K,double** kt,int ntrain, int ntest,int* itrain,int* itest){

    int i,j;
 
    #pragma omp parallel for shared(kt) private(i)
    for(i=0;i<ntrain;i++){
        
         #pragma omp parallel for shared(kt,i) private(j)                      //codeP
         for(j=0;j<ntest;j++){

             kt[j][i]=K[itrain[i]][itest[j]];
             
    }
    }
}

//parallelized
void lu_gauss(double** Amatrix,int n,double* grid_f_copy){
    
	int r,c,i,j,k,l;
    double factor;

   for (k = 0; k < n-1; k++) {
	#pragma omp parallel for shared(Amatrix) private(r,c,factor)
        for (r = k+1; r < n; r++) {
            factor = Amatrix[r][k]/Amatrix[k][k]; 
              
            for (c = k+1; c < n; c++) {
                Amatrix[r][c] = Amatrix[r][c] - factor*Amatrix[k][c];
            }
            Amatrix[r][k] = factor;
        }     
    }

    for(i=1;i<n;i++){
            #pragma omp parallel for shared(i) private(j)
            for(j=i;j<n;j++){
                grid_f_copy[j] = grid_f_copy[j] - Amatrix[j][i-1]*grid_f_copy[i-1];
            }
        }

    for (k = n-1; k > 0; k--) {
	{
        	grid_f_copy[k] = grid_f_copy[k]/Amatrix[k][k];
        	#pragma omp parallel for shared(k) private(l) 
        	for (l = 0; l < k; l++) 
            		grid_f_copy[l] = grid_f_copy[l] - Amatrix[l][k]*grid_f_copy[k]; 
	}
    }

    grid_f_copy[0] = grid_f_copy[0]/Amatrix[0][0];

}

//paralllelized
double dotProduct(double* f1,double* f2, int n){
    double sum = 0.0;
    int v=0;
    #pragma omp parallel for default(shared) private(v) reduction(+: sum)

        for(v=0;v<n;v++){
             sum += f1[v] * f2[v] ; 
        }   
    return sum;
}

//shuffle the indices of training and testing set
int* shuffle(int n) 
{
    int* r = malloc(n * sizeof(int));
    for(int i=0;i<n;i++){
        r[i]=i;
    }
    for(int i=0; i<n; i++){
        int randIdx = rand() % n;
        int t = r[i];
        r[i] = r[randIdx];
        r[randIdx] = t;
    }
   
  return r;
}

//parallelized
void matvec(double** matrix,double* vector,double* result,int siz_i,int siz_j){
    int i,j;
    #pragma omp parallel shared(matrix,result,vector) private(i,j)
    {
        #pragma omp for schedule(static)
        for (i=0;i<siz_i;i++){
            result[i]=0;
            for(j=0;j<siz_j;j++){
                result[i]=(result[i])+(matrix[i][j] * vector[j]);
            }
        }
    }
}



void exec_GPR(int n,struct XY *grid_XY,double** K0, double** A,double* grid_f_train,double** kt,double* f_test,int ntest,int ntrain,int* itest,int* itrain,double l1, double l2){
    
     initialize_Kmatrix(K0,n,grid_XY,l1,l2);
     initialize_Atrain(K0,A,ntrain,itrain);

     init_smallk(K0,kt,ntrain,ntest,itrain,itest);
     lu_gauss(A,ntrain,grid_f_train);
     matvec(kt,grid_f_train,f_test,ntest,ntrain);
}


int main(int argc, char** argv){

    int m,threads;
    double **K_matrix=NULL;
    double **A_matrix = NULL;

    if(argc !=2){
        printf("Incorrect number of arguments,Enter just 1 argument --> m  \n");
        return 0;
    }
    else
    {
        m = atoi(argv[1]);
    }
    
    int numt;
    #pragma omp parallel default(shared)
    {   
        #pragma omp single
        {
            numt = omp_get_num_threads();
            printf("\n Calculating on %dx%d matrix using %d threads \n",m,m,numt);
        }
        
    }
    int n = m*m;
    struct XY *grid_XY = (struct XY *) malloc(n * sizeof(struct XY));
    double *grid_f = (double*) malloc(n * sizeof(double));
    

     initialize_grid(grid_XY,m);
     initialize_f(grid_f,grid_XY,m);
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    //Randomizing training and testing set
    
    int ntest = ceil((double)n/(double)10);
    int ntrain = n-ntest;

    int* r = shuffle(n);
    int* itest = malloc(ntest * sizeof(int));
    int* itrain = malloc(ntrain * sizeof(int));
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    #pragma omp parallel for
    for(int i=0;i<ntest;i++){
        itest[i]=r[i];
    }
    
    #pragma omp parallel for
    for(int i=0;i<ntrain;i++){
        itrain[i]=r[i+ntest];
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    K_matrix = createMatrix(n,n);
    A_matrix = createMatrix(ntrain,ntrain);
  
    double** kt= createMatrix(ntest,ntrain);
    double *grid_f_train = (double*) malloc(ntrain * sizeof(double));
    
  
  double l1,l2,min_l,max_l,l_step;
  int l_len;

  min_l=0.25;
  max_l=10;
  l_step=0.5;
  l_len = ((max_l - min_l)/l_step) + 1;
 

double *mse_matrix = (double*) malloc(l_len*l_len * sizeof(double));
double *mse_matrix2 = (double*) malloc(l_len*l_len * sizeof(double));
// Vector of Lparams 

double *lparam_vec = (double*) malloc(l_len * sizeof(double));
    double *f_test = (double*) malloc(ntest * sizeof(double));
    double *error = (double*) malloc(ntest * sizeof(double));

initialize_lparams(lparam_vec, m,min_l,max_l,l_step,l_len);

//MAJOR CODE START
double my_mse = 100.00;
double my_l1,my_l2;

//MAIN FOR LOOP 

double start_whole = omp_get_wtime();

for(int i=0;i<l_len;i++){

    l1 = lparam_vec[i];
    for(int j=0;j<l_len;j++){
        l2 = lparam_vec[j];
        
        #pragma omp parallel for
        for(int i=0;i<ntrain;i++){
        grid_f_train[i] = grid_f[itrain[i]]; 
    }
    
        exec_GPR(n,grid_XY,K_matrix,A_matrix,grid_f_train,kt,f_test,ntest,ntrain,itest,itrain,l1,l2);

        for(int i=0;i<ntest;i++){
        error[i]=grid_f[itest[i]]-f_test[i];
        }

        double mse=dotProduct(error,error,ntest);
        mse=mse/ntest;
        mse_matrix[(i*l_len)+j]=mse;
        
        
        
        if(mse<my_mse){
            my_mse=mse;
            my_l1=l1;
            my_l2=l2;
        }
  
    }
        
    }
double end_whole = omp_get_wtime();

    
    printf("\n Result on the original data:");
    printf("\n Minimum mse of value %f is obtained at L1,L2 = %f,%f",my_mse,my_l1,my_l2);
    printf("\n Total Time taken= %g seconds\n", end_whole-start_whole);
    

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

//RUNNING ON THE NEW DATA

     initialize_grid2(grid_XY,m);
     initialize_f2(grid_f,grid_XY,m);
     
     double my_mse2 = 100.00;
     double my_l12,my_l22;

//MAIN FOR LOOP ON NEW DATA

double start_whole2 = omp_get_wtime();

for(int i=0;i<l_len;i++){

    l1 = lparam_vec[i];
    for(int j=0;j<l_len;j++){
        l2 = lparam_vec[j];
        
        #pragma omp parallel for
        for(int i=0;i<ntrain;i++){
        grid_f_train[i] = grid_f[itrain[i]]; 
        }
    
        exec_GPR(n,grid_XY,K_matrix,A_matrix,grid_f_train,kt,f_test,ntest,ntrain,itest,itrain,l1,l2);

        for(int i=0;i<ntest;i++){
        error[i]=grid_f[itest[i]]-f_test[i];
        }

        double mse2=dotProduct(error,error,ntest);
        mse2=mse2/ntest;
        mse_matrix2[(i*l_len)+j]=mse2;
        

        if(mse2<my_mse2){
            my_mse2=mse2;
            my_l12=l1;
            my_l22=l2;
        }
  
    }
        
}
double end_whole2 = omp_get_wtime();

    
    printf("\n Result on the NEW data:");
    printf("\n Minimum mse of value %f is obtained at L1,L2 = %f,%f",my_mse2,my_l12,my_l22);
    printf("\n Total Time taken= %g seconds\n", end_whole2-start_whole2);
    
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    
    
    
    free(K_matrix);
    free(A_matrix);
    free(grid_XY);
    free(grid_f_train);
    free(grid_f);
    free(itest);
    free(itrain);
    free(f_test);
    free(error);
    free(kt);
    
    return 0;
}