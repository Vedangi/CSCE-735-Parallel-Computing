#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>


#define D_random ((double)rand()/(10.0 * (double)RAND_MAX)) - 0.05

struct XY{
    double x;
    double y;
}XY;


void initialize_grid(struct XY *grid_XY, int m){
    double h = 1.0 / (double)(m + 1);
    int idx = 0;

    for(int i = 0; i < m; i++) {
        for(int j = 0; j < m; j++) {
            grid_XY[idx].x = (i + 1) * h;
            grid_XY[idx].y = (j + 1) * h;
            idx++;
        }
    }
}

void initialize_f(double* grid_f, struct XY *grid_XY, int n){

    // #pragma omp parallel for shared(grid_f,n)  //codeP
    for(int id = 0; id < n; id++) {
        grid_f[id] = 1 - (((grid_XY[id].x - 0.5) * (grid_XY[id].x - 0.5)) + ((grid_XY[id].y - 0.5) * (grid_XY[id].y - 0.5))) + D_random;
    }
}


void print_grid(struct XY *grid_XY, int m){
    printf("\n Printing Grid \n");
    int idx = 0;
    for(int i=0; i<m; i++){
        for(int j=0; j<m; j++){
            printf("(%5.5lf %5.5lf) ", grid_XY[idx].x, grid_XY[idx].y);
            idx++;
        }
        printf("\n");
    }
}


void printF(double *f, int m){
   
    int idx = 0;
    for(int i=0; i<m; i++){
        for(int j=0; j<m; j++){
            printf("(%5.5lf) ", f[idx]);
            idx++;
        }
        printf("\n");
    }
}

double** createMatrix(int r, int c){
    double **null_matrix = NULL;
    null_matrix = (double**)malloc(r * sizeof(double*));
    for(int i=0; i<r; i++){
        null_matrix[i] = (double*)malloc(c * sizeof(double));
    }
    
    return(null_matrix);
}


void initialize_Kmatrix(double** kmatrix, int n, struct XY *grid_XY)
{   

    double dist,dist_x,dist_y;

    // #pragma omp parallel for collapse(2) shared(kmatrix,n) //codeP
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            dist_x = pow(grid_XY[i].x - grid_XY[j].x, 2);
            dist_y = pow(grid_XY[i].y - grid_XY[j].y, 2);
            kmatrix[i][j] = exp(-1 * (dist_x + dist_y));
            
            if(i == j)
                kmatrix[i][j] = kmatrix[i][j] + 0.01;
        }
    }
    
}

void print_matrix(double** matrix,int n){
  
    for(int i = 0;i < n;i++){
        for(int j = 0; j < n ;j++){
            printf("%3.3lf ",matrix[i][j]);
        }
        printf("\n");
    }
}

	


void lu_factors2(double** Amatrix,int n){
    
  

	long i,j,k;
    double pivot;

   for (k = 0; k < n-1; k++) {
        pivot = Amatrix[k][k]; 
	#pragma omp parallel for 
        for (i = k+1; i < n; i++) {
            Amatrix[i][k] = Amatrix[i][k]/pivot; 
        }
        #pragma omp parallel for collapse(2) 
        for (i = k+1; i < n; i++) {
            for (j = k+1; j < n; j++) {
                Amatrix[i][j] = Amatrix[i][j] - Amatrix[i][k]*Amatrix[k][j];
            }
        }
    }
}

void LU_solver(int n,double** LU_matrix,double* grid_f_copy){
        int i,j,k,l;
        for(i=1;i<n;i++){
            #pragma omp parallel for shared(i) private(j)
            for(j=i;j<n;j++){
                grid_f_copy[j] = grid_f_copy[j] - LU_matrix[j][i-1]*grid_f_copy[i-1];
            }
        }
    
    //////////////////////////////////////////////////////////////////////////////////////////

        
    for (k = n-1; k > 0; k--) {
	{
        	grid_f_copy[k] = grid_f_copy[k]/LU_matrix[k][k];
        	#pragma omp parallel for shared(k) private(l) 
        	for (l = 0; l < k; l++) 
            		grid_f_copy[l] = grid_f_copy[l] - LU_matrix[l][k]*grid_f_copy[k]; 
    
	}
    }
    grid_f_copy[0] = grid_f_copy[0]/LU_matrix[0][0];


}

void lu_gauss(double** Amatrix,int n,double* grid_f_copy){
    
  
	int r,c,i,j,k,l;
    double factor;

   for (k = 0; k < n-1; k++) {
	#pragma omp parallel for shared(Amatrix) private(r,c,factor)
        for (r = k+1; r < n; r++) {
            factor = Amatrix[r][k]/Amatrix[k][k]; 
              
            for (c = k+1; c < n; c++) {
                Amatrix[r][c] = Amatrix[r][c] - factor*Amatrix[k][c];
            }
            Amatrix[r][k] = factor;
        }     
    }

    for(i=1;i<n;i++){
            #pragma omp parallel for shared(i) private(j)
            for(j=i;j<n;j++){
                grid_f_copy[j] = grid_f_copy[j] - Amatrix[j][i-1]*grid_f_copy[i-1];
            }
        }

    for (k = n-1; k > 0; k--) {
	{
        	grid_f_copy[k] = grid_f_copy[k]/Amatrix[k][k];
        	#pragma omp parallel for shared(k) private(l) 
        	for (l = 0; l < k; l++) 
            		grid_f_copy[l] = grid_f_copy[l] - Amatrix[l][k]*grid_f_copy[k]; 
    
	}
    }

    grid_f_copy[0] = grid_f_copy[0]/Amatrix[0][0];

}

double dotProduct(double* f1,double* f2, int n){
    double sum = 0.0;
    int v=0;
    #pragma omp parallel for default(shared) private(v) reduction(+: sum)

        for(v=0;v<n;v++){
             sum += f1[v] * f2[v] ; 
        }   
    
    return sum;

}

int main(int argc, char** argv){

    int m,threads;
    double sum = 0.0;
    double rstar_x,rstar_y;
    double **K_matrix=NULL;
    double **A_matrix = NULL;
  


    

    if(argc !=4){
        printf("Incorrect number of arguments,Enter 3 arguments m,rstar_x and rstar_y  \n");
        return 0;
    }
    else
    {
        m = atoi(argv[1]);
        rstar_x = atof(argv[2]);
        rstar_y = atof(argv[3]);
        // threads = atof(argv[4]);
        
    }
    if(rstar_x >= m || rstar_x < 0 || rstar_y >=m || rstar_y < 0)
    {
        printf("Given point is out of range.Please enter rstar within 0<=rstar<m range");
        return 0;
    }
    // else
    // {
    //     printf("\n Calculating predicted value of rstar(%5.4lf,%5.4lf) in a %d x %d matrix",rstar_x,rstar_y,m,m);
    
    // }
    
    // omp_set_num_threads(threads);
    // int numt;
    // #pragma omp parallel default(shared)
    // {   
    //     #pragma omp single
    //     {
    //         numt = omp_get_num_threads();
    //         printf("\n Total number of threads are %d",numt);
    //     }
        
    // }
    int n = m*m;
    struct XY *grid_XY = (struct XY *) malloc(n * sizeof(struct XY));
    double *grid_f = (double*) malloc(n * sizeof(double));
    double *grid_f_copy = (double*) malloc(n * sizeof(double));
    double *k_t = (double*) malloc(n * sizeof(double));
    double *f_check = (double*) malloc(n * sizeof(double));

     initialize_grid(grid_XY,m);
     initialize_f(grid_f,grid_XY,n);

     long gid=0;
     for(int i=0; i<m; i++){
        for(int j=0; j<m; j++){
            grid_f_copy[gid]=grid_f[gid];
            gid++;
        }
    }

    //  print_grid(grid_XY,m);
    //  printF(grid_f,m);

    
    K_matrix = createMatrix(n,n);
    A_matrix = createMatrix(n,n);
  
    initialize_Kmatrix(K_matrix,n,grid_XY);

    for(int i =0;i<n;i++){
        for(int j=0;j<n;j++){
            A_matrix[i][j] = K_matrix[i][j];
          
        }
    }
    
    // printf("\n Printing A matrix \n");
    // print_matrix(A_matrix,n);

    double start_lu_solver = omp_get_wtime();
    // lu_factors2(A_matrix,n);
    //LU_solver(n,A_matrix,grid_f_copy);
    lu_gauss(A_matrix,n,grid_f_copy);
    double end_lu_solver = omp_get_wtime();
    double time_lu_solver = end_lu_solver - start_lu_solver;

    // printf("\n Printing z \n");
    // printF(grid_f_copy,m);

    
    //kt initialization
    double dist_x, dist_y;
    for(int i = 0; i < n; i++) {
        dist_x = pow(grid_XY[i].x - rstar_x, 2);
        dist_y = pow(grid_XY[i].y - rstar_y, 2);
        k_t[i] = exp(-1 * (dist_x + dist_y));
    }

    sum = dotProduct(k_t,grid_f_copy,n);
    printf("\n Predicted value is = %3.5lf \n",sum);
    
    printf("Time taken by LU and Triangular Solvers = %g seconds\n", time_lu_solver );
   
    
   
    
    free(K_matrix);
    free(A_matrix);
    free(k_t);
    free(f_check);
    free(grid_XY);
    free(grid_f);
    free(grid_f_copy);
    
    return 0;
}